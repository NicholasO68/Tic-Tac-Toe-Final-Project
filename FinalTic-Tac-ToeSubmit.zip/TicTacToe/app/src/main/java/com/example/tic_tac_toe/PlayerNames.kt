package com.example.tic_tac_toe

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.tic_tac_toe.databinding.ActivityPlayerNamesBinding

class PlayerNames : AppCompatActivity() {
    private lateinit var binding: ActivityPlayerNamesBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPlayerNamesBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)
    }
    fun confirmFunction(view: View){
        var intent  = Intent(this,MainActivity::class.java)
        intent.putExtra("nameOne", binding.playerOne.text.toString())
        intent.putExtra("nameTwo", binding.playerTwo.text.toString())
        startActivity(intent)
    }
}
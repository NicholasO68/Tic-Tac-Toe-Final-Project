package com.example.tic_tac_toe

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import androidx.appcompat.app.AlertDialog
import com.example.tic_tac_toe.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    enum class Turn{
        NOUGHT,
        CROSS
    }

    private var firstTurn = Turn.CROSS
    private var currentTurn = Turn.CROSS

    private var player1Score = 0
    private var player2Score = 0

    private var boardList = mutableListOf<Button>()

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        initBoard()

    }
    private fun initBoard(){
        boardList.add(binding.button1)
        boardList.add(binding.button2)
        boardList.add(binding.button3)
        boardList.add(binding.button4)
        boardList.add(binding.button5)
        boardList.add(binding.button6)
        boardList.add(binding.button7)
        boardList.add(binding.button8)
        boardList.add(binding.button9)
    }
    fun helpMe(view: View){
        var intent  = Intent(this,Help::class.java)
        startActivity(intent)
    }
    fun prefView(view: View){
        var intent = Intent(this,Preferences::class.java)
        startActivity(intent)
    }
    fun nameChange(view: View){
        var intent = Intent(this,PlayerNames::class.java)
        startActivity(intent)
    }

    fun boardTapped(view: View){
        if(view !is Button)
            return
        addToBoard(view)

        if(winGame(NOUGHT)){
                player1Score++
                result("Player 1 Wins!")
        }
        if(winGame(CROSS)){
                player2Score++
                result("Player 2 Wins!")
        }


        if(fullBoard()){
            result("Draw")
        }
    }

    private fun winGame(s: String): Boolean {

        //Horizontal Wins
        if (match(binding.button1,s) && match(binding.button2,s) && match(binding.button3,s))
            return true
        if (match(binding.button4,s) && match(binding.button5,s) && match(binding.button6,s))
            return true
        if (match(binding.button7,s) && match(binding.button8,s) && match(binding.button9,s))
            return true

        //Vertical Wins
        if (match(binding.button1,s) && match(binding.button4,s) && match(binding.button7,s))
            return true
        if (match(binding.button2,s) && match(binding.button5,s) && match(binding.button8,s))
            return true
        if (match(binding.button3,s) && match(binding.button6,s) && match(binding.button9,s))
            return true

        //Diagonal Wins
        if (match(binding.button1,s) && match(binding.button5,s) && match(binding.button9,s))
            return true
        if (match(binding.button3,s) && match(binding.button5,s) && match(binding.button7,s))
            return true

        return false
    }

    private fun match(button: Button, symbol: String): Boolean = button.text == symbol

    private fun result(title: String){
        val message = "\nPlayer 1: $player1Score\n\nPlayer 2: $player2Score"
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Reset")
            { _,_ ->
                resetBoard()

            }
            .setCancelable(false)
            .show()
    }

    private fun resetBoard(){
        for(button in boardList){
            button.text = ""
        }

        if(firstTurn == Turn.NOUGHT)
            firstTurn = Turn.CROSS
        else if(firstTurn == Turn.CROSS)
            firstTurn = Turn.NOUGHT

        firstTurn = currentTurn
        setTurnLabel()
    }

    private fun fullBoard(): Boolean{
        for(button in boardList){
            if(button.text == "")
                return false
        }
        return true
    }

    private fun addToBoard(button: Button){
        if(button.text != "")
            return
        if(currentTurn == Turn.NOUGHT){
            button.text = NOUGHT
            currentTurn = Turn.CROSS
        }
        else if(currentTurn == Turn.CROSS){
            button.text = CROSS
            currentTurn = Turn.NOUGHT
        }
        setTurnLabel()
    }

    private fun setTurnLabel(){
        var turnBody = ""
        if(currentTurn == Turn.CROSS)
            binding.turnText.text = intent.getStringExtra("nameOne")
        if(currentTurn == Turn.NOUGHT)
            binding.turnText.text = intent.getStringExtra("nameTwo")
        if(intent.getStringExtra("nameOne") == null)
            turnBody = "Player 1"
        if(intent.getStringExtra("nameTwo") == null)
            turnBody = "Player 2"
    }

    companion object{
        const val NOUGHT = "O"
        const val CROSS = "X"
    }
}
